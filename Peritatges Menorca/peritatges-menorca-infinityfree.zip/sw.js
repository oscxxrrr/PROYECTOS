const CACHE_NAME = 'peritatges-menorca-v2';
const SHELL_CACHE = 'peritatges-menorca-shell-v2';

const SHELL_URLS = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/icons/icon.svg'
];

self.addEventListener('install', (event) => {
  // Precarga la carcasa de la app sin que un fallo bloquee la instalacion
  event.waitUntil(
    caches.open(SHELL_CACHE)
      .then((cache) => Promise.all(
        SHELL_URLS.map((url) => cache.add(url).catch(() => true))
      ))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME && key !== SHELL_CACHE)
          .map((key) => caches.delete(key))
      );
    }).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // El API se deja pasar SIEMPRE al servidor (o al fallback si red fuera)
  if (request.url.includes('/api/') || url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => new Response(response.body, {
          status: response.status,
          statusText: response.statusText,
          headers: response.headers
        }))
        .catch(() => new Response(
          JSON.stringify({ offline: true, message: 'Modo sin conexion' }),
          { status: 503, headers: { 'Content-Type': 'application/json' } }
        ))
    );
    return;
  }

  // Navegaciones (HTML): red primero, fallback a la carcasa cacheada
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
          return response;
        })
        .catch(() => caches.match(request).then((cached) =>
          cached || caches.match('/index.html')
        ))
    );
    return;
  }

  // Assets estaticos (JS/CSS con hash): caché primero con actualizacion en 2º plano
  if (request.method === 'GET') {
    event.respondWith(
      caches.open(CACHE_NAME).then((cache) =>
        cache.match(request).then((cached) => {
          const networkFetch = fetch(request)
            .then((response) => {
              if (response && response.status === 200 && response.type === 'basic') {
                cache.put(request, response.clone());
              }
              return response;
            })
            .catch(() => cached);
          return cached || networkFetch;
        })
      )
    );
    return;
  }

  // Resto: red
  event.respondWith(fetch(request));
});